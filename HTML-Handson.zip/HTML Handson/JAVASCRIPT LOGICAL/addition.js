const addition = function() {
    const a;
    const b;
    const c = a + b;
    console.log(c);
}