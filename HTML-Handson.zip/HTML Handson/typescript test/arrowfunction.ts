
    let names=new Array('tom','ivan','jerry');
   for(var i=0;i<names.length;i++)
   {
        let lengths = names.map((string) => string.length);
    console.log({name:names[i],length:lengths[i]});
   }

        
 
