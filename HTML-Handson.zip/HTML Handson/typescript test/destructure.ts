let employee=['chandler','bing','female'];
let[fname,lname,gender="male"]=employee;
console.log(fname);
console.log(lname);
console.log(gender);


let organization={
    empname:'chandler',
    address:
    {
        street:'pearl',
        city:'california',
        pincode:7890
    }
};

let{empname:e,address:{street:s,city:c,pincode:p}}=organization;

console.log(e);
console.log(s);
console.log(c);
console.log(p===7890);
