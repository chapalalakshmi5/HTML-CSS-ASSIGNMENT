var add=function(a=10,b=20)
{
    console.log(a+b);
}
add();  
add(30,50);

var userfriends=function(user,...friends)
{
    console.log();
    console.log(user);
    console.log(friends);
    for(let i in friends)
    console.log(friends[i]);
}
let user="username: Harry";
userfriends(user,'Tom','jerry','ivan');
userfriends(user,'Emma','Oliva');



var PrintCapitalLetterNames=function(capital,...capitalletters)
{
 console.log();
 console.log(capital);
 for(var i in capitalletters)
 console.log(capitalletters[i].toUpperCase( ))
}
let capital="capital letters";
let namesArray=['orange','white','pink'];
PrintCapitalLetterNames(capital,...namesArray)