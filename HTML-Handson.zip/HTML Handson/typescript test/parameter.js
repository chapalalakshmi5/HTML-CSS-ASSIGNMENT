var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var add = function (a, b) {
    if (a === void 0) { a = 10; }
    if (b === void 0) { b = 20; }
    console.log(a + b);
};
add();
add(30, 50);
var userfriends = function (user) {
    var friends = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        friends[_i - 1] = arguments[_i];
    }
    console.log();
    console.log(user);
    console.log(friends);
    for (var i in friends)
        console.log(friends[i]);
};
var user = "username: Harry";
userfriends(user, 'Tom', 'jerry', 'ivan');
userfriends(user, 'Emma', 'Oliva');
var PrintCapitalLetterNames = function (capital) {
    var capitalletters = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        capitalletters[_i - 1] = arguments[_i];
    }
    console.log();
    console.log(capital);
    for (var i in capitalletters)
        console.log(capitalletters[i].toUpperCase());
};
var capital = "capital letters";
var namesArray = ['orange', 'white', 'pink'];
PrintCapitalLetterNames.apply(void 0, __spreadArray([capital], namesArray, false));
