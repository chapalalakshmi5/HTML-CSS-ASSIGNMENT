var names = new Array('tom', 'ivan', 'jerry');
for (var i = 0; i < names.length; i++) {
    var lengths = names.map(function (string) { return string.length; });
    console.log({ name: names[i], length: lengths[i] });
}
