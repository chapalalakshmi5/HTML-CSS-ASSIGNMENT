var num1=10;
var num2=20;
if(num1<num2)
{
    let num4=30;
    console.log(num1);
    console.log(num2);
    console.log(num4);
}
/*<--------outside variable calling------>*/
/*console.log(num4);*/

  