var Order = {
    id: 90,
    title: "T-shirt",
    price: "2000",
    printOrder: function () {
        console.log(Order);
    },
    getprice: function () {
        console.log(Order.price);
    }
};
var returnedOrder = Object.assign({}, Order);
console.log(returnedOrder);
/*<-----------printOrder method and price called------------>*/
/*console.log(Order.printOrder());
console.log(Order.getprice());*/ 
