var fibonacci = /** @class */ (function () {
    function fibonacci() {
        this.previousno = 5;
    }
    fibonacci.prototype.next = function () {
        console.log('previousno:', this.previousno);
        var a = this.previousno * (1 + Math.sqrt(5)) / 2.0;
        return Math.round(a);
    };
    return fibonacci;
}());
var pt = new fibonacci();
console.log('currentno', +pt.next());
