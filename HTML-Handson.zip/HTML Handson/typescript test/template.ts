var username="Emma";
var lpmodel=9087;
var deskno=8097;

var raiseticket=`This is ${username}, my laptop is not working properly last one day
and my laptop model is ${lpmodel} desknumber is ${deskno}`;
console.log(raiseticket);
