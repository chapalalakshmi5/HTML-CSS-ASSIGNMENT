var Order={
    id:90,
    title:"T-shirt",
    price:"2000",
    printOrder(){
console.log(Order);
    },
getprice(){
     console.log(Order.price);
}


};
var returnedOrder=(<any>Object).assign({},Order);
console.log(returnedOrder);

/*<-----------printOrder method and price called------------>*/
/*console.log(Order.printOrder());
console.log(Order.getprice());*/