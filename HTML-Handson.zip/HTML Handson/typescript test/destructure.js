var employee = ['chandler', 'bing', 'female'];
var fname = employee[0], lname = employee[1], _a = employee[2], gender = _a === void 0 ? "male" : _a;
console.log(fname);
console.log(lname);
console.log(gender);
var organization = {
    empname: 'chandler',
    address: {
        street: 'pearl',
        city: 'california',
        pincode: 7890
    }
};
var e = organization.empname, _b = organization.address, s = _b.street, c = _b.city, p = _b.pincode;
console.log(e);
console.log(s);
console.log(c);
console.log(p === 7890);
