var employee1 = {
    name: "chandler",
    id: 90
};
var circle = {
    radius: 2
};
function printAll(employee1, circle) {
    console.log(employee1.name + " " + employee1.id);
    console.log(circle.radius);
}
printAll(employee1, circle);
