class fibonacci
{
    private previousno=5;
    next()
    {
        console.log('previousno:',this.previousno);
       var a = this.previousno * (1 + Math.sqrt(5)) / 2.0;
        return Math.round(a);
       
}
}
const pt=new fibonacci();
console.log('currentno',+pt.next());
