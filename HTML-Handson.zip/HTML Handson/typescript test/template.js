var username = "Emma";
var lpmodel = 9087;
var deskno = 8097;
var raiseticket = "This is ".concat(username, ", my laptop is not working properly last one day\nand my laptop model is ").concat(lpmodel, " desknumber is ").concat(deskno);
console.log(raiseticket);
