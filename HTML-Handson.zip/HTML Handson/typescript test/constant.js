var obj1 = {
    name: "emma"
};
console.log(obj1.name);
obj1.name = "Oliva";
console.log(obj1.name);
