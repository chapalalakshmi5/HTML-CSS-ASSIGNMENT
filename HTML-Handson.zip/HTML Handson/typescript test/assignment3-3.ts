interface Printable
{
    name?: string;
    id?:number;
    radius?:number;
}

var employee1: Printable = 
{
    name:"chandler",
    id:90
};

var circle: Printable = 
{
    radius:2
};

function printAll(employee1, circle)
{
    console.log(employee1.name + " " + employee1.id);
    console.log(circle.radius);
}
printAll(employee1,circle);